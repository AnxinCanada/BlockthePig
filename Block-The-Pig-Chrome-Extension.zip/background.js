chrome.runtime.onInstalled.addListener(function (object) {
    let externalUrl = "data:text/html, <h1>Thank You for Installing Block the Pig!</h1><p><b>Install Info</b><br>Version: 1.1.0 BETA<br>Developer: Eric Pan<br>Manifest Version: 2</p>";
    let internalUrl = chrome.runtime.getURL("views/onboarding.html");

    if (object.reason === chrome.runtime.OnInstalledReason.INSTALL) {
        chrome.tabs.create({ url: externalUrl }, function (tab) {
            console.log("New tab launched");
        });
    }
});