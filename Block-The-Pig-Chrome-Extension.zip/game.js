setTimeout(function(){
    if(document.getElementsByTagName("canvas").length) {
      document.getElementsByTagName("body")[0].classList.add("no-select")
    }
  }, 2000);
function setUserAgent(window, userAgent) {
 // Works on Firefox, Chrome, Opera and IE9+
  if (navigator.__defineGetter__) {
      navigator.__defineGetter__("userAgent", function () {
          return userAgent;
      });
  } else if (Object.defineProperty) {
      Object.defineProperty(navigator, "userAgent", {
          get: function () {
              return userAgent;
          }
      });
  }
  // Works on Safari
  if (window.navigator.userAgent !== userAgent) {
      var userAgentProp = {
          get: function () {
              return userAgent;
          }
      };
      try {
          Object.defineProperty(window.navigator, "userAgent", userAgentProp);
      } catch (e) {
          window.navigator = Object.create(navigator, {
              userAgent: userAgentProp
          });
      }
  }
}
if(window.navigator.userAgent.indexOf("Safari")>=0 && "ontouchstart" in window && window.navigator.userAgent.indexOf("iPhone")== -1) {
  //var userAgent = window.navigator.userAgent.replace("Macintosh", "iPad");
  var userAgent = "Mozilla/5.0 (iPad; CPU OS 13_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.1 Mobile/15E148 Safari/604.1";
  setUserAgent(window,userAgent);
}
	// Issue a warning if trying to preview an exported project on disk.
	(function(){
		// Check for running exported on file protocol
		if (window.location.protocol.substr(0, 4) === "file")
		{
			alert("Exported games won't work until you upload them. (When running on the file:/// protocol, browsers block many features from working for security reasons.)");
		}
	})();

		// Size the canvas to fill the browser viewport.
		jQuery(window).resize(function() {
			cr_sizeCanvas(jQuery(window).width(), jQuery(window).height());
		});
		
		// Start the Construct 2 project running on window load.
		jQuery(document).ready(function ()
		{			
			// Create new runtime using the c2canvas
			cr_createRuntime("c2canvas");
		});
		
		// Pause and resume on page becoming visible/invisible
		function onVisibilityChanged() {
			if (document.hidden || document.mozHidden || document.webkitHidden || document.msHidden)
				cr_setSuspended(true);
			else
				cr_setSuspended(false);
		};
		
		document.addEventListener("visibilitychange", onVisibilityChanged, false);
		document.addEventListener("mozvisibilitychange", onVisibilityChanged, false);
		document.addEventListener("webkitvisibilitychange", onVisibilityChanged, false);
		document.addEventListener("msvisibilitychange", onVisibilityChanged, false);
		

        function fnSendMsg(evt){
        	window.parent.postMessage('keypress-from-game', '*');
        }
        document.body.addEventListener('click', function(event) {
          fnSendMsg(event);
        });
        document.addEventListener('keypress', function(event) {
        	 fnSendMsg(event);
        });
        document.addEventListener('keydown', function (e) {
        	 fnSendMsg(event);
        });
        document.addEventListener('keyup', function (e) {
        	  fnSendMsg(event);
        });
        